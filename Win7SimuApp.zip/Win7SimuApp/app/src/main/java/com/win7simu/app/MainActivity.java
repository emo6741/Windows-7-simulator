package com.win7simu.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Simülatör arayüzü ana WebView'de çalışır. Simülatördeki tüm tarayıcı pencereleri
 * (Chrome, Internet Explorer, Nova, kurulan web uygulamaları) gerçek Android WebView
 * olarak, pencerenin içerik alanının üstüne yerleştirilir (AndroidBridge ile).
 */
public class MainActivity extends Activity {

    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final String UA = "Mozilla/5.0 (Linux; Android 13; Tablet) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private FrameLayout root;
    private WebView main;
    private WebViewAssetLoader loader;
    private final Map<String, WebView> views = new LinkedHashMap<>();
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        setContentView(root);

        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        main = new WebView(this);
        configure(main);
        main.addJavascriptInterface(new Bridge(), "AndroidBridge");
        main.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String h = r.getUrl().getHost();
                if ("appassets.androidplatform.net".equals(h)) return false;
                openExternal(r.getUrl().toString());
                return true;
            }
        });
        main.setWebChromeClient(new WebChromeClient());
        root.addView(main, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        main.loadUrl(START_URL);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configure(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
    }

    private void setupChild(final WebView w) {
        w.getSettings().setUserAgentString(UA);
        w.getSettings().setSupportZoom(true);
        w.getSettings().setBuiltInZoomControls(true);
        w.getSettings().setDisplayZoomControls(false);
        w.getSettings().setUseWideViewPort(true);
        w.getSettings().setLoadWithOverviewMode(true);
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                if ("http".equals(sc) || "https".equals(sc) || "about".equals(sc)) return false;
                openExternal(r.getUrl().toString());
                return true;
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = v; customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }
            @Override
            public void onHideCustomView() { hideCustom(); }
        });
        w.setDownloadListener((url, ua, cd, mime, len) -> openExternal(url));
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
    }

    private void openExternal(String url) {
        try {
            Intent i = url.startsWith("intent:") ? Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                    : new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(i);
        } catch (Exception ignored) { }
    }

    /** Ekranda görünen (en üstteki) alt WebView'i bul. */
    private WebView topVisible() {
        WebView t = null;
        for (WebView w : views.values()) if (w.getVisibility() == View.VISIBLE) t = w;
        return t;
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        WebView t = topVisible();
        if (t != null && t.canGoBack()) { t.goBack(); return; }
        super.onBackPressed();
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override protected void onPause() {
        super.onPause();
        main.onPause();
        for (WebView w : views.values()) w.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        main.onResume();
        for (WebView w : views.values()) w.onResume();
    }

    @Override protected void onDestroy() {
        for (WebView w : views.values()) w.destroy();
        views.clear();
        main.destroy();
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    //  JS köprüsü
    // ------------------------------------------------------------------
    public class Bridge {

        @JavascriptInterface
        public void create(final String id, final String url) {
            runOnUiThread(() -> {
                if (views.containsKey(id)) return;
                WebView w = new WebView(MainActivity.this);
                configure(w);
                setupChild(w);
                w.setVisibility(View.GONE);
                root.addView(w, new FrameLayout.LayoutParams(1, 1));
                views.put(id, w);
                w.loadUrl(url);
            });
        }

        @JavascriptInterface
        public void setRect(final String id, final int x, final int y, final int w, final int h, final boolean vis) {
            runOnUiThread(() -> {
                WebView v = views.get(id);
                if (v == null) return;
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
                int ww = Math.max(1, w), hh = Math.max(1, h);
                if (lp.leftMargin != x || lp.topMargin != y || lp.width != ww || lp.height != hh) {
                    lp.leftMargin = x; lp.topMargin = y; lp.width = ww; lp.height = hh;
                    v.setLayoutParams(lp);
                }
                int want = vis ? View.VISIBLE : View.GONE;
                if (v.getVisibility() != want) v.setVisibility(want);
            });
        }

        @JavascriptInterface
        public void navigate(final String id, final String url) {
            runOnUiThread(() -> { WebView v = views.get(id); if (v != null) v.loadUrl(url); });
        }

        @JavascriptInterface
        public void reload(final String id) {
            runOnUiThread(() -> { WebView v = views.get(id); if (v != null) v.reload(); });
        }

        @JavascriptInterface
        public void back(final String id) {
            runOnUiThread(() -> { WebView v = views.get(id); if (v != null && v.canGoBack()) v.goBack(); });
        }

        @JavascriptInterface
        public void forward(final String id) {
            runOnUiThread(() -> { WebView v = views.get(id); if (v != null && v.canGoForward()) v.goForward(); });
        }

        @JavascriptInterface
        public void destroy(final String id) {
            runOnUiThread(() -> {
                WebView v = views.remove(id);
                if (v == null) return;
                root.removeView(v);
                v.destroy();
            });
        }

        /** Site başlığını ve ikonunu çeker; sonucu window[cb]({title, icon}) ile döner. */
        @JavascriptInterface
        public void fetchSiteInfo(final String url, final String cb) {
            if (cb == null || !cb.matches("[A-Za-z0-9_]+")) return;
            new Thread(() -> {
                JSONObject o = new JSONObject();
                try {
                    SiteInfo.fill(url, o);
                } catch (Exception ignored) { }
                final String js = "window['" + cb + "']&&window['" + cb + "'](" + o.toString() + ")";
                runOnUiThread(() -> main.evaluateJavascript(js, null));
            }).start();
        }
    }

    // ------------------------------------------------------------------
    //  Site başlığı + ikon çekme
    // ------------------------------------------------------------------
    static final class SiteInfo {
        private static final Pattern TITLE = Pattern.compile("<title[^>]*>(.*?)</title>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        private static final Pattern SITE = Pattern.compile("<meta[^>]+property=[\"']og:site_name[\"'][^>]*content=[\"']([^\"']+)", Pattern.CASE_INSENSITIVE);
        private static final Pattern LINK = Pattern.compile("<link\\b[^>]*>", Pattern.CASE_INSENSITIVE);
        private static final Pattern REL = Pattern.compile("rel=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);
        private static final Pattern HREF = Pattern.compile("href=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);

        static void fill(String pageUrl, JSONObject o) throws Exception {
            URL base = new URL(pageUrl);
            String[] ct = new String[1];
            byte[] raw = get(pageUrl, 600000, ct);
            String html = raw == null ? "" : new String(raw, "UTF-8");

            String title = null;
            Matcher m = SITE.matcher(html);
            if (m.find()) title = m.group(1);
            if (title == null) { m = TITLE.matcher(html); if (m.find()) title = m.group(1); }
            if (title != null) {
                title = title.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
                        .replace("&lt;", "<").replace("&gt;", ">").replaceAll("\\s+", " ").trim();
                o.put("title", title);
            }

            List<String> apple = new ArrayList<>(), other = new ArrayList<>();
            Matcher lm = LINK.matcher(html);
            while (lm.find()) {
                String tag = lm.group();
                Matcher r = REL.matcher(tag), h = HREF.matcher(tag);
                if (!r.find() || !h.find()) continue;
                String rel = r.group(1).toLowerCase();
                if (!rel.contains("icon")) continue;
                try {
                    String abs = new URL(base, h.group(1)).toString();
                    (rel.contains("apple") ? apple : other).add(abs);
                } catch (Exception ignored) { }
            }
            List<String> cands = new ArrayList<>(apple);
            cands.addAll(other);
            cands.add(base.getProtocol() + "://" + base.getHost() + "/favicon.ico");

            for (int i = 0; i < cands.size() && i < 5; i++) {
                String[] ict = new String[1];
                byte[] img = get(cands.get(i), 300000, ict);
                if (img == null || img.length < 60) continue;
                String mime = ict[0] != null ? ict[0].split(";")[0].trim() : "";
                if (!mime.startsWith("image/")) {
                    String u = cands.get(i).toLowerCase();
                    mime = u.contains(".svg") ? "image/svg+xml" : u.contains(".ico") ? "image/x-icon"
                            : u.contains(".jpg") || u.contains(".jpeg") ? "image/jpeg" : "image/png";
                }
                o.put("icon", "data:" + mime + ";base64," + Base64.encodeToString(img, Base64.NO_WRAP));
                break;
            }
        }

        private static byte[] get(String url, int max, String[] ctOut) {
            try {
                for (int hop = 0; hop < 5; hop++) {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    c.setRequestProperty("User-Agent", UA);
                    int code = c.getResponseCode();
                    if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                        url = new URL(new URL(url), c.getHeaderField("Location")).toString();
                        c.disconnect();
                        continue;
                    }
                    if (code != 200) { c.disconnect(); return null; }
                    if (ctOut != null) ctOut[0] = c.getContentType();
                    InputStream in = c.getInputStream();
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0 && out.size() < max) out.write(buf, 0, n);
                    in.close();
                    c.disconnect();
                    return out.toByteArray();
                }
            } catch (Exception ignored) { }
            return null;
        }
    }
}
